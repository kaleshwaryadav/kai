<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage T2i
 * @since 1.0
 * @version 1.2
 */

?>



<!-- footer starts here -->
<footer>
	<div class="container">
		<div class="row footer-main">
			<div class="col-md-4 col-sm-4 col-xs-4">
				<h4><?php the_field('quick_link_heading', 'option') ?></h4>
				<?php wp_nav_menu( array(
					'theme_location' => 'quick',
					'menu_id'        => 'quick-menu',
					'menu_class' => 'list-unstyled',
					) ); ?>
				</div>
				<div class="col-md-4 col-sm-4 col-xs-4">
					<h4><?php the_field('category_heading', 'option') ?></h4>
					<?php wp_nav_menu( array(
						'theme_location' => 'categories',
						'menu_id'        => 'categories-menu',
						'menu_class' => 'list-unstyled',
						) ); ?>
					</div>
					<div class="clearfix visible-xs"></div>
					<div class="col-md-4 col-sm-4 col-xs-4">
						<h4><?php the_field('social_network_heading', 'option') ?></h4>
						
						<?php wp_nav_menu( array(
							'theme_location' => 'social',
							'menu_id'        => 'social-menu',
							'menu_class' => 'list-unstyled list-inline social-list',
							) ); ?>

							<div class="feeback-box">
								<a href="<?php echo get_permalink(83); ?>"><span class="fa fa-comments-o"></span>  Submit Feedback</a>
							</div>
						</div>
					</div>
				</div>	
				<div class="copyright-sec text-center">
					<p><?php the_field('copyright', 'option') ?></p>
				</div>
			</footer>

			
		

			<script type="text/javascript">
    //          var url = "<?php echo get_template_directory_uri(); ?>";
				// bkLib.onDomLoaded(function() {
				// 	new nicEditor({iconsPath : url+'/nicEditorIcons.gif'}).panelInstance('area3');
				// });
			</script>
			<script type="text/javascript">
				// jQuery(function () {
				// 	jQuery('#datetimepicker1').datetimepicker();

				// });
               jQuery(function () {
                    $('.accessMSG').click(function(e){
                         alert("Please register first to access it");
                    });
                   
                });
             function cloning(){
                alert("Sorry,You can't cloning this assert");
                return false;
             }
			</script>
			<?php wp_footer(); ?>

		</body>
		</html>
