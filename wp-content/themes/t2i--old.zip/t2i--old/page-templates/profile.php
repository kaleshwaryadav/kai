<?php
/*
 * Template Name: Profile
 */

get_header(); 
if(!is_user_logged_in()) {
$url = esc_url( home_url( '/' ) );?>
<script>
 document.location.href = "<?php echo $url;  ?>";
</script>
<?php } 
$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name =  get_user_meta($user_id,'first_name',true);
$gender =  get_user_meta($user_id,'gender',true);
$company =  get_user_meta($user_id,'company',true);
$dob = get_user_meta($user_id,'dob',true);
$mobilenum = get_user_meta($user_id,'mobilenum',true);
$address = get_user_meta($user_id,'address',true);
$alternateemail = get_user_meta($user_id,'alternateemail',true);
$user_type = get_user_meta($user_id,'user_type',true);
$comp_vat = get_user_meta($user_id,'comp_vat',true);
$location = get_user_meta($user_id,'location',true);

?>
<!-- logout popup -->
<!-- logout popup -->
<div id="logout_pop" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<!--  <h4 class="modal-title">Modal Header</h4> -->
			</div>
			<div class="modal-body text-center">
				<p>Are you sure you want to Logout?</p>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="btn" >Yes</button>
				<button type="button" class="btn btn_black" data-dismiss="modal">No</button>
			</div>
		</div>

	</div>
</div>

<!-- logout popup -->
<!-- logout popup -->


<!-- main-body section starts here -->

<div class="template-wrapper extended">
	<section>
		<div class="container">
			<div class="breadcrumb">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
                <div class="alert alert-success text-center" style="display:none;">
                  <strong>Thanks!</strong> Your profile has been successfully updated.
                </div>
			</div>
			<form id="myForm" method="POST">
			<div class="head_ttl">
              <input type="hidden" name="action" value="profile_save">
                <?php if (function_exists('wp_nonce_field')) {
                 wp_nonce_field('rs_user_profile_action', 'rs_user_profile_action_nonce');
                 } ?>
				<h2>My Profile</h2>
               
    			</div>

				<div class="profile_form">
					<div class="user_picture">
						<div class="rem_dp">
							<div class="profile_dp">
                            <?php  $ImageUrl = get_user_meta($user_id,'user_picImage',true); 
                             if(!empty($ImageUrl)){?>
                             <img src="<?php echo $ImageUrl; ?>" id="blah" alt="profilepic">
                             <?php } else { ?>
                            <img src="<?php bloginfo('template_url') ?>/assets/images/profile-img.jpg" iid="blah" alt="profilepic">
                            <?php } ?>
							
								<div class="upload_dp">
									<input type="file" name="profile_pic"  value="" class="form-control img" accept="image/-png,image/gif,image/jpeg" id="uplaod_dp">
									<label for="uplaod_dp"><i></i></label>
								</div>

							</div>
							<div class="blockdiv">
								<a href="#" class="removedp" data-id="8" >Change photo</a>
							</div>
							<input type="submit" name="profile" id="profile" id="edit_prof" class="btn edit_prof profile-update-button" value="Save Changes" >
						</div>

					</div>
					<div class="user_detail">
						<ul>
							<li>
								<ul>
									<li><span>User Type :</span><input type="text" name="user_type" id="user_type" value="<?php echo $user_type; ?>"></li>
									<li><span>Company vat Number :</span><input type="number" id="comp_vat" name="comp_vat" value="<?php echo $comp_vat; ?>"></li>
								</ul>
							</li>
							<li>
								<ul>
									<li><span>Name :</span><input type="text" name="first_name" id="first_name" value="<?php echo $current_user->user_firstname; ?>"></li>
									<li><span>Gender :</span><input type="text" name="gender" id="gender" value="<?php echo $gender; ?>"> </li>
								</ul>
							</li>
							<li>
								<ul>
									<li><span>Email :</span><input type="email" id="email" name="email" value="<?php echo $current_user->user_email; ?>"> </li>
									<li><span>DOB :</span><input type="date" id="dob" name="dob" value="<?php echo $dob; ?>"></li>
								</ul>
							</li>
							<li>
								<ul>
									<li><span>Company :</span><input type="text" name="company" id="company" value="<?php echo $company; ?>"></li>
									
								</ul>
							</li>
							<li>
								<ul>
									<li><span>Mobile Number :</span><input type="number" name="mobilenum" id="mobilenum" value="<?php echo $mobilenum; ?>"></li>									
								</ul>
							</li>
							<li>
								<ul>									
									<li><span>Address :</span><input type="text" name="address" id="address" value="<?php echo $address; ?>"></li>           
								</ul>
							</li>
							<li>
								<ul>
                                    <li><span>Location :</span><input type="text" name="location" id="location" value="<?php echo $location; ?>"></li>
								</ul>
							</li>
							<li>
								<ul>
									<li><span>Alternate Email :</span><input type="text" id="alternateemail" name="alternateemail" value="<?php echo $alternateemail; ?>"> </li>
								</ul>
							</li>
							
						</ul>
						<separator></separator>
						
					</div>
				</div>
			</form>
		</div>	
	</section>
</div>	<!-- template wrapper ends here -->
<script type="text/javascript">
	jQuery(function () {
		jQuery('#datetimepicker1').datetimepicker();
        jQuery('.alert-success').hide();


	});


$('#myForm').submit(function() {
    $('#profile').val('processing..');
     $.ajax({            
            type: "POST", 
            action : "profile_save",
            url: theme_ajax.url,
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData:false, 
            success: function (response) {
            $('#profile').val('Save profile');
            $('.alert-success').fadeIn("slow");
            $('html, body').animate({scrollTop: '0px'}, 800);
            setTimeout(function(){ $('.alert-success').hide(); }, 4000);
            },
            error: function (responseData) {
                console.log('Ajax request not recieved!');
            }
        });
     return false;

});

 function readURL(input) {

     var filename = $('input[type=file]').val();
     var extn = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
     if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") { 
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
        }
        else
       {
       alert("Please select only images");
      }
    }
    
    $('input[type=file]').change(function(){
     readURL(this);
     var filename = $('input[type=file]').val();
     var extn = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
     if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") { 
     }
    });
</script>

<!-- <style>
 button,input[type="submit"] 
</style> -->
<?php get_footer();
