<?php
/*
 * Template Name: Sign Up
 */

get_header(); ?>

<!-- main-body div starts here -->
<script type='text/javascript'>
function refreshCaptcha(){
    var img = document.images['captchaimg'];
    img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
<div class="success-sec">
	<div class="container ">
		<div class="breadcrumb">
			<?php if(function_exists('bcn_display'))
			{
				bcn_display();
			}?>
		</div>
		<h1 class="text-center">Sign Up</h1>
        <div class="status"></div>
		<div>
			<form method="POST" id="rsUserRegistration">
				<div class="form_div">

					<div class="row">
						<div class="col-sm-12">
                            <div class="form-group group">
                            <input type="hidden" name="action" value="user_registration">
                            <?php if (function_exists('wp_nonce_field')) {
                             wp_nonce_field('rs_user_registration_action', 'rs_user_registration_nonce');
                             } ?>

                                <input type="text" placeholder="" class="form-control" id="username" name="username" required>
                                <label class="label_for" >Username:<span>*</span></label>
                                <span class="bar"></span>
                            </div>
							<div class="form-group group">

								<input type="email" placeholder="" class="form-control" id="email" name="email" required>
								<label class="label_for" >Email:<span>*</span></label>
								<span class="bar"></span>
							</div>
							
							<div class="form-group group">

								<input type="password" placeholder="" class="form-control" id="user_password" name="user_password" required>
								<label class="label_for" >Password:<span>*</span></label>
								<span class="bar"></span>
							</div>
							<div class="form-group group">

								<input type="password" placeholder="" class="form-control" id="user_confrm_password" name="user_confrm_password" required>
								<label class="label_for">Confirm password:<span>*</span></label>
								<span class="bar"></span>
							</div>
							<span class="tag">Captcha:</span>
							<div class="form-group group captcha">
								<div class="dis_table">
									<div class="dis_cell">
										<input type="text" placeholder="" class="form-control" id="captcha_code" name="captcha_code" required>
										<label class="label_for" for="captcha_code">Enter Captcha:</label>
										<span class="bar"></span>
									</div>
									<div class="dis_cell captcha_img"><img src="<?php echo get_template_directory_uri(); ?>/template-captcha.php?rand=<?php echo rand();?>" id='captchaimg'></div>
								</div>
							</div>
							<div class="form_group">
								<div class="checkbox">
									<div class=" pos-rel">
										<input type="checkbox" id="iagree" name="iagree" required>
										<label class="label_for" for="iagree">By signing up, you agree to our <a href="<?php echo get_permalink(45); ?>">T&C</a> and <a href="<?php echo get_permalink(43); ?>">Privacy Policy</a></label>
									</div>
								</div>
							</div>


						</div><!--col-sm-6-->
					</div><!--row-->
				</div>
				<div class=" slider_cont text-center ">
					<input type="submit" class="btn" id="signup" name="signup" value="Sign up">
					<p>Already a member? <a href="<?php echo get_permalink(32); ?>">Login Now!</a></p>
				</div>
			</form>

		</div>
	</div>	
</div>

<?php get_footer();
