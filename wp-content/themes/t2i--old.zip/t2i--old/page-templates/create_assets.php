<?php
/*
 * Template Name: Create Assets
 */

get_header(); 

if(!is_user_logged_in()) {
$url = esc_url( home_url( '/login' ) );?>
<script>
 document.location.href = "<?php echo $url;  ?>";
</script>
<?php } ?>
<!-- logout popup -->
<div id="logout_pop" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<!--  <h4 class="modal-title">Modal Header</h4> -->
			</div>
			<div class="modal-body text-center">
				<p>Are you sure you want to Logout?</p>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="btn" >Yes</button>
				<button type="button" class="btn btn_black" data-dismiss="modal">No</button>
			</div>
		</div>

	</div>
</div>

<!-- logout popup -->
<!-- logout popup -->


<!-- main-body section starts here -->

<div class="template-wrapper extended">
	<section>
		<div class="container">
			<div class="breadcrumb">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
			</div>
			<div class="head_ttl">
				<h2>Create New Assest</h2>
				<!--  <a href="#" class="print"></a> -->
			</div>
			<div class="templates">
				<div class="row">
					<div class="col-sm-12">
						<div class="bg_white category_list">
						<span class="tag">Choose Category :</span>
                        <span class="select_cat form-group">
                         <select name="category" id="category">
                          <option value="" selected="selected">Please select category</option>
                        <?php
                        $categories = get_categories( array(
                                    'orderby' => 'name',
                                    'order'   => 'ASC',
                                    'category__not_in' => array( '1' ),
                                ) );
                       if($categories){
                          foreach($categories as $item){?>
                                 <option value="<?php echo $item->term_id; ?>"><?php echo $item->name; ?></option>
                        <?php }
                       }
                        ?>
                        </select>
							 <i class="fa ddw"></i>
                             <span id="Msg" style="color:red; display:none;">Please Choose Category</span>
							</span>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="col-md-4">
						<div class="box">
							<div class="temp_box">
								<a href="javascript:void(0);" data-url="<?php echo get_permalink(87); ?>">
									<img class="onLoad" src="<?php bloginfo('template_url') ?>/assets/images/img_temp2.jpg" alt="img_template">
									<img class="onHover" src="<?php bloginfo('template_url') ?>/assets/images/img_temp1.jpg" alt="img_template">
								</a>
							</div>
							<h4>Image Template</h4>
						</div>
					</div>
					<div class="col-md-4">
						<div class="box">
							<div class="temp_box">
								<a  href="javascript:void(0);" data-url="<?php echo get_permalink(91); ?>">
									<img class="onLoad" src="<?php bloginfo('template_url') ?>/assets/images/electro_tem2.jpg" alt="electronic_template">
									<img class="onHover" src="<?php bloginfo('template_url') ?>/assets/images/electro_tem1.jpg" alt="electronic_template">
								</a>
							</div>
							<h4>Electronic Template</h4>
						</div>

					</div>
					<div class="col-md-4">
						<div class="box">
							<div class="temp_box">
								<a href="javascript:void(0);" data-url="<?php echo get_permalink(89); ?>">
									<img class="onLoad" src="<?php bloginfo('template_url') ?>/assets/images/small_temp2.jpg" alt="small_template">
									<img class="onHover" src="<?php bloginfo('template_url') ?>/assets/images/small_temp1.jpg" alt="small_template">
								</a>
							</div>
							<h4>Small Business Template</h4>
						</div>
					</div>
				</div>
			</div>

		</div>	
	</section>



</div>	<!-- template wrapper ends here -->
<script>
$(document).ready(function(){
$('.temp_box a').click(function(){
if($('#category').val()==""){
$('#Msg').show();
return false;
}
else
{
$('#Msg').hide();
var url = $(this).attr('data-url'); 
var cartid = $('#category').val();
window.location.href = url+'?cartId='+cartid;
return false;
}

});
});

</script>
<?php get_footer();
