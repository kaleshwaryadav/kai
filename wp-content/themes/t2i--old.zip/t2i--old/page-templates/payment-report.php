<?php
/*
 * Template Name: Payment Report
 */

get_header(); 
if(!is_user_logged_in()) {
$url = esc_url( home_url( '/' ) );?>
<script>
 document.location.href = "<?php echo $url;  ?>";
</script>
<?php } 
$current_user = wp_get_current_user();
$user_id = $current_user->ID;
?>
<!-- main-body section starts here -->
<div class="template-wrapper extended">
	<section>
		<div class="container" style="width:1350px; margin:auto;">
			<div class="breadcrumb">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
               
			</div>
          <?php $obj= new UserReports();
         $UserList = $obj->invoice_report_user();         
         $asset_user = get_userdata($user_id);
         $address =  get_user_meta($user_id,'address',true);
         $payment_mode = get_field('gateway_mode', 'option');
         if($payment_mode=="Test"){
            $paypal_url = get_field('test_url', 'option');
            $business_id = get_field('test_account_business_id', 'option');
         }
         else{
            $paypal_url = get_field('live_url', 'option');
            $business_id = get_field('business_id', 'option');
         }
         $successful_url = get_field('successful_payment_url', 'option');
         $failure_url = get_field('failure_payment_url', 'option');
       ?>

          <div id="dashboard-widgets-wrap">
            <div id="dashboard-widgets" class="metabox-holder">
            <div class="tableSec report-t2iwp">
            <?php
              $filterByDate = $_GET['filter'] ? $_GET['filter'] : "";
              $datefilter = explode('-',$filterByDate);
              $y = $datefilter[0];
              $m = $datefilter[1];
              $d = $datefilter[2];
              if(!empty($filterByDate)){              
              $fullm = date('M Y', strtotime($filterByDate));
              }
              else {
              $fullm = date('M Y');
              }
              $filter = array();
              $newdate = date("Y-m", strtotime("-1 months"));
              $filter_custom = date("Y-m", strtotime($y."-".$m));
              // echo "newdate~~~~~".$newdate;
              // echo "<br>";
              // echo "filter_custom~~~~~".$filter_custom;
              if($newdate>=$filter_custom)
              {
              if(!empty($filterByDate)){
               $filterData = UserReports::filter_by_month_year($y,$m,$user_id);
              }
              else {
                 $filterData = UserReports::frontend_report_of_user($user_id);
              }
              }
              ?>            
              Filter By (Month and Year):
              <form action="" method="get" >
             <input type="month" id="month" name="filter" value="<?php echo $filterByDate; ?>">
             <input type="submit" value="Search">
            </form>
       <div class="month_filter" style="margin-bottom:10px; "><strong>Month:</strong> <?php echo $fullm; ?> </div>
       <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="0">
         <thead>
           <tr>
             <!-- <th>Owner ID#</th> -->
             <th>Owner info </th>
             <th>Asset Details</th>
             <th>Invoice Details</th>             
             <th>Outstanding Balance</th>
             <th>Price reduction</th>
             <th>Invoice Value Brutto</th>
             <th>Thereof VAT 19%:</th>
             <th>Invoice Value Netto</th>
             <th>Payment Status</th>
             <!-- <th>Generate Invoice / Requrest Payment</th> -->
             </tr>
         </thead>
        
             <tbody>
         <?php
              global  $current_user, $wpdb;
              $table_name = $wpdb->prefix . "montly_payment_report";
              //echo $fullm;
              if(!empty($filterByDate)){
               $sql = "SELECT * FROM $table_name where UserID='$user_id' and Month='$m' and Year='$y' order by YearMonth desc";
              }
              else{                
                $sql = "SELECT * FROM $table_name where UserID='$user_id' order by YearMonth desc";
              }
              //echo $sql;
              $result = $wpdb->get_results($sql);
              foreach( $result as $results ) {
                $owner_id = $results->UserID;
                $asset_user = get_userdata($owner_id);
                $user_displayname = $asset_user->user_firstname;
                $address =  get_user_meta($owner_id,'address',true);
                $total_asset = $results->TotalNoAssets;
                $invoiceID = $results->ID;
                $invoiceMonth = $results->Year."-".$results->Month;
                $invc_month = strtotime($invoiceMonth);
                //echo $invc_month;
                $convert_date = date('M Y', strtotime($invoiceMonth));
                $total_earning = $results->Total_Earning;
                $start_date = date('01-m-Y', strtotime($invoiceMonth));
                $end_date = date('t-m-Y', strtotime($invoiceMonth));
                $total_assets = $results->TotalNoAssets;
                $total_views = $results->Total_Views;
                $total_clone = $results->Total_Clones;
                $total_share = $results->Total_Shares;
                $total_favorits = $results->Total_Favorits;
                $total_reminder = $results->Total_Reminder;
                $total_url_calls = $results->Total_Url_Calls;
                $total_downloads = $results->Total_Downloads;
                $total_report_calls = $results->Total_Report_Calls;
                $total_message_sent = $results->Total_Message_Sent;
                $created_date = $results->Last_Fetch_Report_DateTime;
                $item_name = 'Invoice_#'.$invoiceID."_".$user_displayname."_".date('F Y', strtotime($invoiceMonth));
                //echo $item_name;
                ?>
                <tr>
                     <!-- <td><?php echo $owner_id; ?></td> -->
                     <td><?php echo $user_displayname; ?><br><?php echo $address; ?><br/>
                     Created Date: <?php echo $created_date; ?> 
                   </td>
                     <td>
                      <table>
                        <tr>
                          <td>Total Assets</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_assets; ?></td>
                        </tr>
                        <tr>
                          <td>Total Views</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_views; ?></td>
                        </tr>
                        <tr>
                          <td>Total Clones</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_clone; ?></td>
                        </tr>
                        <tr>
                          <td>Total Share</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_share; ?></td>
                        </tr>
                        <tr>
                          <td>Total Favourites</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_favorits; ?></td>
                        </tr>
                        <tr>
                          <td>Total Reminder</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_reminder; ?></td>
                        </tr>
                        <tr>
                          <td>Total URL Calls</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_url_calls; ?></td>
                        </tr>
                        <tr>
                          <td>Total Downloads</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_downloads; ?></td>
                        </tr>
                        <tr>
                          <td>Total Report Calls</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_report_calls; ?></td>
                        </tr>
                        <tr>
                          <td>Total Message Sent</td>
                          <td>:</td>
                          <td style="text-align: right;"><?php echo $total_message_sent; ?></td>
                        </tr>
                        <tr>
                                                 
                          <td colspan="2" style="text-align: center;"><a class="payment_view_more" href="<?php echo site_url(); ?>/report/?filter=<?php echo $invoiceMonth;  ?>">View Details</a></td>
                        </tr>
                      </table>                      
                     </td>                     
                     
                     <td><b>Invoice ID : #<?php echo $invoiceID; ?></b><br/>
                      <?php
                      $monthname = date('F Y', strtotime($invoiceMonth)); 
                      echo $monthname;?><br/>
                      <?php echo $start_date." to ".$end_date; ?></td>
                     <td style="text-align: center;"><?php echo round($total_earning,2); ?> €</td>
                     <td style="text-align: center;"><?php echo get_price_reduction_by_month($results->Month, $owner_id);?></td>
                     <td style="text-align: center;">
                      <?php                     
                      

                      $price_reduction = get_price_reduction_by_month($results->Month, $owner_id);
                      $price_reduction_type = substr($price_reduction, -1);
                      if($price_reduction_type=='%'){
                          $invoice_brutto = ($total_earning*$price_reduction)/100;
                          $final_brutto = $total_earning - $invoice_brutto;
                        }
                        else{
                          $final_brutto = $total_earning-$price_reduction;                          
                        }
                      echo round($final_brutto,2);
                      ?>
                     €</td>
                     <td style="text-align: center;">
                      <?php
                      //$after_vat = ($final_brutto*19)/100;
                      $after_vat = 19/119*$final_brutto;
                      echo round($after_vat,2);
                      ?>

                     €</td>
                     <td style="text-align: center;"><?php
                      $final_payment_amount = $final_brutto - $after_vat;                      
                      $f_amount = round($final_payment_amount,2);
                      echo $f_amount;
                      ?> €</td>
                     <!-- <td><?php echo $results->Payment_Status ?></td> -->
                     <td style="text-align: center;"><?php if($results->Payment_Status=='0'){
                        $f_amount = round($final_payment_amount,0);
                          ?>                      
                          <form action="<?php echo $paypal_url; ?>" method="post" target="_blank">
                          <!-- Identify your business so that you can collect the payments. -->
                          <input type="hidden" name="business" value="<?php echo $business_id; ?>">        
                          <!-- Specify a Buy Now button. -->
                          <input type="hidden" name="cmd" value="_xclick">        
                          <!-- Specify details about the item that buyers will purchase. -->
                          <input type="hidden" name="item_name" value="<?php echo $item_name; ?>">
                          <input type="hidden" name="item_number" value="<?php echo $invoiceID; ?>">
                          <input type="hidden" name="amount" value="<?php echo $f_amount; ?>">
                          <input type="hidden" name="currency_code" value="USD">        
                          <input type="hidden" name="rm" value="2" />      
                          <!-- Specify URLs -->
                          <input type='hidden' name='cancel_return' value='<?php echo $failure_url; ?>'>
                          <input type='hidden' name='return' value='<?php echo $successful_url; ?>'>        
                          <!-- Display the payment button. -->
                          <input class="paypal_paynow_btn" type="submit" name="submit" value="Pay Now">
                          </form>

                      


                      <?php } else if($results->Payment_Status=='1'){?>
                        <span class="status-complete">Complete</span>                        
                        <a href="<?php echo site_url()."/transaction-details/?invoice_id=$invoiceID&userid=$owner_id" ?>" class="paypal_transaction_btn">Transaction Details</a>
                      <?php }?>                        
                    </td>
                  </tr>
                  <?php 
              }
              ?>
       
        <?php if(count($filterData)==0){ ?>
        <div style='color:red; text-align:center; margin-top:20px;'>Sorry no records found!</div>
        <?php } ?>
         </tbody>
            </table>
     </div>

   </div>
 </div>
  </div>	
  </section>
  </div>	<!-- template wrapper ends here -->
<?php get_footer(); ?>
