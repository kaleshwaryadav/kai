<?php
/*
 * Template Name: Private Message
 */
get_header(); ?>
<div class="template-wrapper">
	<div>
		<div class="container">
			<div class="breadcrumb">
				<?php if(function_exists('bcn_display'))
				{
					bcn_display();
				}?>
			</div>
        <?php 
        global  $current_user, $wpdb;
        $table_name = $wpdb->prefix . "asset_message";
        $user_id = get_current_user_id();
        $sql = "SELECT * FROM $table_name where asset_ownerid='$user_id'";
        //echo $sql;
        $messageList = $wpdb->get_results($sql);
       // echo "<pre>";
       // print_r($messageList);       
        ?>
			<div class="success-sec dashboard">
				<h3>Private Messager</h3>
        <table id="private_message_inbox" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Asset Details</th>
                <th>Sender Info</th>                
                <th>Message</th>                
            </tr>
        </thead>
        <tbody>
          <?php  foreach($messageList as $messagekey) {
            $asset_title = get_the_title($messagekey->post_id);
            $asset_url = get_the_permalink($messagekey->post_id);
            ?>
            <tr>
                <td>Name of Asset : <b><?php echo $asset_title; ?>(<?php echo $messagekey->post_id; ?>)</b><br> 
                    Asset Url : <b><?php echo $asset_url; ?></b><br> 
                </td>
                <td>Sender Name: <b><?php echo $messagekey->message_name; ?></b><br>
                    Sender Email: <b><?php echo $messagekey->message_email; ?></b><br>
                    Sender Mobile No : <b><?php echo $messagekey->message_mobile_no; ?></b><br>
                    Sender Address : <b><?php echo $messagekey->message_address; ?></b><br>
                    Created Date Time : <b><?php echo $messagekey->date; ?></b>
                </td>                            
                <td><?php echo $messagekey->message; ?></td>         
            </tr>
          <?php } ?>
      </tbody>
    </table> 
	   </div>
</div>	
</div>
</div>	<!-- template wrapper ends here -->

<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('#private_message_inbox').dataTable();
});
</script>
<?php get_footer();?>
