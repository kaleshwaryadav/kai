<?php
/*
 * Template Name: Product Detail Owner
 */

get_header(); 
if(!is_user_logged_in()) {
$url = esc_url( home_url( '/' ) );?>
<script>
 document.location.href = "<?php echo $url;  ?>";
</script>
<?php } ?>

<?php 
$astid = base64_decode($_GET['astid']); 
$asset_name = get_field('name',$astid, true);
$asset_business = get_field('business_name',$astid, true);
$price = get_field('price',$astid, true);
$link = get_field('link',$astid, true);
$short_description  = get_field('short_description',$astid, true);
$asset_download = get_field('download_file',$astid, true);
$ass_desc = get_post($astid);
$assert_desc = $ass_desc->post_content;

$ImageUrl = wp_get_attachment_image_src( get_post_thumbnail_id( $astid ), 'full');
$asset_link = get_field('asset_link', $astid, true);
$secon_desc =  get_field('description_business', $astid, true);
?>
<!-- main-body div starts here -->
<div class="template-wrapper">
    <div>
      <div class="container">
        <div class="breadcrumb">
			<?php if(function_exists('bcn_display'))
			{
			bcn_display();
			}
            ?>
			</div>
			<div class="head_ttl">
			<h2><?php echo get_the_title($astid); ?></h2>
			<a href="#target" class="print"></a>

			</div>
            <div class="product_details">
			 <form method="post" id="edit_asset" >
                <input type="hidden" name="action" value="edit_assets">
                <input type="hidden" name="asset_id" value="<?php echo $astid; ?>">
                 <?php if (function_exists('wp_nonce_field')) {
                  wp_nonce_field('edit_profile_action', 'edit_profile_action_nonce');
                  } ?>
                <div class="row uploader-text">
                    <div class="col-md-6 col-sm-12 col-xs-12 no-padding">
                        <div class="uploader-main" style='background-image: url("<?php echo $ImageUrl[0];  ?>");'>
                            <img id="placeholder-img" class="img-responsive center-block" src="<?php bloginfo('template_url') ?>/assets/images/image_uploader.png" alt="">
                            <?php
                            echo do_shortcode('[media_upload_for_front_upload]');
                            ?>
                        </div>
                        <div id="thumbnail-gallery" class="thumbnail-gallery">
                            <ul class="list-unstyled list-inline"> 
                            <?php $gallery =  get_field('select_image',$astid,true);
                             if(!empty($gallery)){
                             foreach($gallery as $gids){?>
                                 <li class="image" data-attachment_id="<?php echo $gids['ID']; ?>" style="cursor: default;">
                                    <img src="<?php echo $gids['url']; ?>">
                                    <span class="action-delete" onclick="testCall(this,<?php echo $gids['ID'];?>)">×</span>             
                                </li>
                              <?php }} ?>
                            <li class="add-image add-product-images tips" data-title="Add gallery image" data-original-title="" title="">
                                <span class="add-product-images"  id="add-gallery-images"><i class="fa fa-plus" aria-hidden="true"></i></span>
                            </li>           
                            </ul>
                            <input type="hidden" id="product_image_gallery" name="product_image_gallery">   
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                    
                        <div class="txt-title">
                        <input class="w-75 form-control" type="text" placeholder="Product Title" id="temp_title" name="temp_title" value="<?php echo get_the_title($astid);  ?>">
                        </div>
                        <div class="txt-title">
                        <input class="w-75 form-control" type="text" placeholder="assets Name" id="asset_name" name="asset_name" value="<?php echo $asset_name; ?>">
                        </div>

                        <div class="txt-title">
                      <input class="w-75 form-control" type="text" placeholder="Short Description" id="short_desc" name="short_desc" value="<?php echo $assert_desc; ?>">
                        </div>                        

                        <div class="txt-editor">
                           <?php wp_editor( $short_description, 'temp_description', array( 'theme_advanced_buttons1' => 'bold, italic, ul, pH, pH_min', "media_buttons" => false, "textarea_rows" => 8, "tabindex" => 4 ) ); ?>
                        </div>
                        <?php if(!empty($secon_desc)){ ?>
                        <div class="txt-editor">
                           <?php wp_editor($secon_desc, 'second_description', array( 'theme_advanced_buttons1' => 'bold, italic, ul, pH, pH_min', "media_buttons" => false, "textarea_rows" => 8, "tabindex" => 4 ) ); ?>
                        </div>
                        <?php } ?>
                        <div style="clear:both;"></div>
                        <div class="txt-title" style="position: relative; top:35px;">
                        <input class="w-75 form-control" type="text" placeholder="Please enter asset link here" id="asset_link" name="asset_link" value="<?php echo $asset_link; ?>">
                        </div>
                        <?php 

                        if(!empty($price)){?>
                        <div class="publish-sec">
                         <input class="w-75 form-control" type="number" placeholder="Price" id="temp_price" name="temp_price" value="<?php echo $price; ?>">
                         </div>
                       <?php  } 
                        else if(!empty($link)){?>
                        <div class="publish-sec">
                         <input class="w-75 form-control" type="text" placeholder="Please enter assert order link" id="order_link" name="order_link">
                         </div>
                        <?php } 
                         else if(!empty($asset_download)){ ?>
                        <div class="txt-editor">
                        <div class="col-md-5 col-sm-5 col-xs-12 no-padding">
                        <div class="uploader-user">
                        <input type="file" name="downloadfile" id="downloadfile"  accept="image/-png,image/gif,image/jpeg">
                          <!--   <label for="upload-1">
                                <span class="btn">Select file</span>
                            </label>  -->
                        </div>
                    </div>
                        </div>
                         <?php }?>
                         <div class="publish-sec">
                         	<div class="save-draft-text">
                         	 <span>Save as Draft :</span>
                         	</div>
                         	 <div class="publish-sec-divide">
                         	 	<input class='toggle' type="checkbox" <?php if($ass_desc->post_status=='publish'){ echo'checked="checked"'; }?>   name='post_status_checked'/>
                         	</div>
                         </div>
                         	<ul class="inline-btn-group">
                         		<li>
                           <a target="_blank" href="<?php echo get_the_permalink($astid); ?>" class="btn btn_bdr">View Asset</a></li>
                           <li> 
                           <button type="submit" class="btn"><img src="<?php bloginfo('template_url') ?>/assets/images/load-more.gif" class="loading-image" id="loading-image" style="display: none;"></i>Update Now</button>
                       	</li>
                       </ul>

                        <div class="txt-title">
                        <div class="post_status" style="color:green; text-align:right;"></div>
                        <div class="plan_error" style="color:red;"></div>
                    </div>

                        </div>
                        
                    </div>
                </div>  
            </form>
		</div>  
	</div>

	<div class="partner-list">
		<div class="container">
		<div class="row">
		<?php get_template_part( 'layout/template', 'ads');?>
			</div>
		</div>  
	</div>

	<div>
		 <?php //get_template_part( 'layout/template', 'share');?>
	</div>
</div>  <!-- template wrapper ends here -->

<!-- share product popup -->
<!-- share product popup -->
<div id="share_product" class="modal fade reminder_popup" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Share this assest via</h4>
			</div>
			<div class="modal-body">
				<div class="form_div feedback">
					<div class="row">
						<div class="col-sm-12">
							<form method="post" >
								<div class="form-group group">
									<input type="email" name="email_product" class="form-control">
									<label >Email Address</label>
									<span class="bar"></span>
								</div>
								<div class="form-group group">
									<textarea class="form-control" ></textarea>
									<label >Message</label>
									<span class="bar"></span>
								</div>
								<div class="form-group">
									<ul class="social_list">
										<li class="fb"><a href="#"><span><i class="fa fa-facebook" aria-hidden="true"></i></span>Facebook</a></li>
										<li class="twt"><a href="#"><span><i class="fa fa-twitter" aria-hidden="true"></i></span>twitter</a></li>
										<li class="gp"><a href="#"><span><i class="fa fa-google-plus" aria-hidden="true"></i></span>google +</a></li>
									</ul>
								</div>

								<div class=" slider_cont text-center">
									<button type="submit" class="btn">submit
									</button>
									
								</div>
							</form>
						</div><!--col-sm-6-->
					</div><!--row-->
				</div>
			</div>
			
		</div>

	</div>
</div>

<!-- share product popup -->
<!-- share product popup -->


<!-- reminder popup -->
<!-- reminder popup -->
<div id="reminder_popup" class="modal fade reminder_popup" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Set Reminder</h4>
			</div>
			<div class="modal-body">
				<div class="form_div feedback">
					<div class="row">
						<div class="col-sm-12">
							<form method="post">
								<div class="form-group group">
									<textarea class="form-control"  ></textarea>
									<label >Message</label>
									<span class="bar"></span>
								</div>
								<span class="tag">Select Date & Time:</span>         
								<div class="row form-group">
									<div class='col-xs-6'>
										<div class="form-group ">
											<div class='input-group date' id='datetimepicker1'>
												<input type='text' class="form-control" placeholder="Date & Time" />
												<span class="input-group-addon">
													<span class="glyphicon glyphicon-calendar"></span>
												</span>
												<span class="bar"></span>
											</div>
										</div>
									</div>
									<div class="col-xs-6">
										<div class="form-group">
											<select>
												<option>daily</option>
												<option selected="selected">weekly</option>
												<option>monthly</option>
											</select>
											<i class="fa fa-sort-desc" aria-hidden="true"></i>
										</div>
									</div>
								</div>
								<div class=" slider_cont text-center">
									<button type="submit" class="btn">save
									</button>
									<button type="submit" class="btn btn_black" data-dismiss="modal">cancel</button>
								</div>
							</form>
						</div><!--col-sm-6-->
					</div><!--row-->
				</div>
			</div>
			
		</div>

	</div>
</div>

<!-- reminder popup -->
<!-- reminder popup -->

<!-- more detail popup -->
<div id="moredetail" class="modal fade" role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="form_div feedback">
					<div class="row">
						<div class="col-sm-12">
							<form method="post">
								<div class="form-group group">
									<input type="text" placeholder="" class="form-control" id="user_priv" name="user_priv">
									<label >User Private</label>
									<span class="bar"></span>
								</div>
								
								<div class="form-group group">
									<input type="text" placeholder="" class="form-control" id="user_owner" name="user_owner">
									<label >User to Owner</label>
									<span class="bar"></span>
								</div>
								<div class="form-group group">
									<input type="text" placeholder="" class="form-control" id="owner_priv" name="owner_priv">
									<label >Owner Private</label>
									<span class="bar"></span>
								</div>
								<div class=" slider_cont text-center">
									<button type="submit" class="btn" name="contact_query">send<span></span>
									</button>
								</div>
							</form>
						</div><!--col-sm-6-->
					</div><!--row-->
				</div>
			</div>
			
		</div>

	</div>
</div>

<!-- more detail popup end -->

<style>
.uploader-main img {
    padding: 50px 0 30px;
    visibility: hidden;
}
i.mce-ico.mce-i-link {
        display: none !important;
    }
</style>

<!-- more detail popup end -->
<script type="text/javascript" src="<?php bloginfo('template_url') ?>/assets/js/lightslider.js"></script>

<script type="text/javascript">

	$(document).ready(function() {
		$('#image-gallery').lightSlider({
			gallery:true,
			item:1,
			thumbItem:4,
			slideMargin: 0,
			speed:500,
			auto:false,
			loop:true,
			onSliderLoad: function() {
				$('#image-gallery').removeClass('cS-hidden');
			}  
		});

   attachment_ids = [];
   jQuery('#thumbnail-gallery .image').each(function () {
        var attachment_id = $(this).attr("data-attachment_id");
        attachment_ids.push( attachment_id );
    });
    $('#thumbnail-gallery #product_image_gallery').val(attachment_ids);
    $('#edit_asset').submit(function() {
    $('#loading-image').show();
     $.ajax({            
            type: "POST", 
            action : "edit_assets",
            url: theme_ajax.url,
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData:false, 
            success: function (response) {
            $('.post_status').html(response);
            $('.post_status').show();
            $('#loading-image').hide();
            setTimeout(function(){// wait for 5 secs(2)
            $('.post_status').hide();
              }, 5000); 
            },
            error: function (responseData) {
                console.log('Ajax request not recieved!');
            }
        });
     return false;

});

	});
</script>
<script type="text/javascript">
	bkLib.onDomLoaded(function() {
        var url = "<?php echo get_template_directory_uri(); ?>";
		new nicEditor({iconsPath : +url'/nicEditorIcons.gif'}).panelInstance('area3');
	});
</script>
<script type="text/javascript">
	// jQuery(function () {
	// 	jQuery('#datetimepicker1').datetimepicker();

	// });
</script>
<script type="text/javascript">

	$('.head_ttl .print').on('click', function(e) {
		e.preventDefault();
		$link = $(this).attr('href');

		$('html, body').animate({
			scrollTop: $($link).offset().top - 10
		}, 800 );
	});

</script>
<?php get_footer();

