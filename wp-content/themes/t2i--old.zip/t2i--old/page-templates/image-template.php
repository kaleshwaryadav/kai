<?php
/*
 * Template Name: Image Template
 */

get_header(); 
if(!is_user_logged_in()) {
$url = esc_url( home_url( '/' ) );?>
<script>
 document.location.href = "<?php echo $url;  ?>";
</script>
<?php } ?>
<?php 
if(!empty($_REQUEST['cloning'])=='done'){
    $asset_title = get_field('asset_title','option');
    $asset_name  = get_field('asset_name','option');
    $assert_desc = strip_tags(get_field('asset_short_description','option'));
    $full_desc   = get_field('asset_full_description','option');
    $price       = get_field('asset_price','option');
    $bannerImag  = get_field('asset_banner_image','option');
    $gallery     = get_field('asset_gallery_image','option');
    $heading_msg = get_field('heading_message','option');
    $asset_order_link = get_field('asset_link','option');


   }
 $template_id = get_field('choose_template_here',get_the_ID());
?>
<!-- main-body section starts here -->
<div class="template-wrapper">
    <section>
        <div class="container">
            <div class="breadcrumb">
                <?php if(function_exists('bcn_display'))
                     {
                    bcn_display();
                   }
                   ?>
            </div>

            <form method="post" id="template-submit-form" class="template-submit-form">
                <input type="hidden" name="action" value="post_template">
                <input type="hidden" name="template_value" value="image-template">
                <input type="hidden" name="category_name" id="category_name" value="<?php echo $_GET['cartId']; ?>">
                <input type="hidden" name="template_id" value="<?php echo $template_id; ?>">
                <input type="hidden" name="cloning" value="<?php echo $_GET['cloning']; ?>">
                <input type="hidden" name="assert_clone_id" value="<?php echo $_GET['astid']; ?>">
                <input type="hidden" name="redirect_page_url" id="redirect_page_url" value="<?php echo get_permalink($post->ID); ?>">

                <div class="row uploader-text">
                <p class="heading_msg"><?php if(!empty($heading_msg)){ echo $heading_msg;} ?></p>
                  <div class="col-md-6 col-sm-12 col-xs-12 no-padding">
                    <div class="uploader-main"  style='background-image: url("<?php echo $bannerImag['url'];  ?>");'>
                            <img id="placeholder-img" class="img-responsive center-block" src="<?php bloginfo('template_url') ?>/assets/images/image_uploader.png" alt="">
                            <?php
                            echo do_shortcode('[media_upload_for_front_upload]');
                            ?>
                        </div>
                        <div id="thumbnail-gallery" class="thumbnail-gallery">
                            <ul class="list-unstyled list-inline">
                            <?php //$gallery =  get_field('select_image',$astid,true);
                              if(!empty($gallery)){
                                foreach($gallery as $gids){?>
                                 <li class="image" data-attachment_id="<?php echo $gids['gallery_image']['ID']; ?>" style="cursor: default;">
                                    <img src="<?php echo $gids['gallery_image']['url']; ?>">
                                    <span class="action-delete" onclick="testCall(this,<?php echo $gids['ID'];?>)">×</span>             
                                </li>
                              <?php }} ?>  
                                <li class="add-image add-product-images tips" data-title="Add gallery image" data-original-title="" title="">
                                <span class="add-product-images"  id="add-gallery-images"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                </li>           
                            </ul>
                            <input type="hidden" id="product_image_gallery" name="product_image_gallery">   
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12 no-padding">
                    
                        <div class="txt-title">
                        <input class="w-75 form-control" type="text" placeholder="asset title" id="temp_title" name="temp_title" value="<?php if(!empty($asset_title)){ echo $asset_title;} ?>">
                        </div>
                        <div class="txt-title">
                        <input class="w-75 form-control" type="text" placeholder="assets Name" id="asset_name" name="asset_name" value="<?php echo $asset_name; ?>">
                        </div>

                        <div class="txt-title">
                      <input class="w-75 form-control" type="text" placeholder="Asset Short Description" id="short_desc" name="short_desc" value="<?php echo $assert_desc; ?>">
                        </div>                        

                        <div class="txt-editor">
                        <p style="color:#9a9494; font-size: 16px;">Asset Description</p>
                           <?php wp_editor( $full_desc, 'temp_description', array( 'theme_advanced_buttons1' => 'bold, italic, ul, pH, pH_min', "media_buttons" => false, "textarea_rows" => 8, "tabindex" => 4 ) ); ?>
                        </div>
                        
                        <div class="txt-title" style="position: relative; top:35px;">
                        <input class="w-75 form-control" type="text" placeholder="Please enter asset link here" id="asset_link" name="asset_link" value="<?php echo $asset_order_link; ?>">
                        </div>

                        
                        <div class="publish-sec">
                            <input class="w-75 form-control" type="number" placeholder="Price" id="temp_price" name="temp_price" value="<?php echo $price; ?>">
                                                      
                        </div>

                        <div class="publish-sec">
                            <div class="save-draft-text">
                             <span>Save as Draft :</span>
                            </div>
                             <div class="publish-sec-divide">
                                <input class='toggle' type="checkbox" name='post_status_checked'/>
                                <?php 
                            $is_active = check_subscription_plan($template_id);
                            if($is_active==0){ ?>
                            <a href="javascript:void(0);" class="btn not_plan_purchaged">Publish</a>
                            <?php } else { ?>
                           <button type="submit" class="btn"><img src="<?php bloginfo('template_url') ?>/assets/images/load-more.gif" class="loading-image" id="loading-image" style="display: none;"></i>Publish</button> <?php } ?>
                            </div>
                         </div>
                         <div class="txt-title">
                        <span class="post_status" style="color:green"></span>
                        <span class="plan_error" style="color:red;"></span>
                    </div>
                    </div>
                </div>  
            </form>
            <div class="row no-margin">
            <h3>Subscription Plan </h3>
             <div class="plan_status"></div>
          
            <div class="row models">

            <?php get_template_part('layout/subscripts', 'plan');?>
                    </div>
                </div>
            
        </div>  
    </section>

    <section class="partner-list">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 col-xs-6 text-center"><a href="#"><img class="img-responsive" src="<?php bloginfo('template_url') ?>/assets/images/partner_list_1.png" alt="partner_list"></a></div>
                <div class="col-sm-3 col-xs-6 text-center"><a href="#"><img class="img-responsive" src="<?php bloginfo('template_url') ?>/assets/images/partner_list_2.png" alt="partner_list"></a></div>
                <div class="col-sm-3 col-xs-6 text-center"><a href="#"><img class="img-responsive" src="<?php bloginfo('template_url') ?>/assets/images/partner_list_3.png" alt="partner_list"></a></div>
                <div class="col-sm-3 col-xs-6 text-center"><a href="#"><img class="img-responsive" src="<?php bloginfo('template_url') ?>/assets/images/partner_list_4.png" alt="partner_list"></a></div>
            </div>
        </div>  
    </section>

    </div>  <!-- template wrapper ends here -->

<!-- share product popup -->
<!-- share product popup -->
<div id="share_product" class="modal fade reminder_popup" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Share this assest via</h4>
            </div>
            <div class="modal-body">
                <div class="form_div feedback">
                    <div class="row">
                        <div class="col-sm-12">
                            <form method="post" action="">
                                <div class="form-group group">
                                    <input type="email" name="email_product" class="form-control">
                                    <label >Email Address</label>
                                    <span class="bar"></span>
                                </div>
                                <div class="form-group group">
                                    <textarea class="form-control" ></textarea>
                                    <label >Message</label>
                                    <span class="bar"></span>
                                </div>
                                <div class="form-group">
                                    <ul class="social_list">
                                        <li class="fb"><a href="#"><span><i class="fa fa-facebook" aria-hidden="true"></i></span>Facebook</a></li>
                                        <li class="twt"><a href="#"><span><i class="fa fa-twitter" aria-hidden="true"></i></span>twitter</a></li>
                                        <li class="gp"><a href="#"><span><i class="fa fa-google-plus" aria-hidden="true"></i></span>google +</a></li>
                                    </ul>
                                </div>

                                <div class=" slider_cont text-center">
                                    <button type="submit" class="btn">submit
                                    </button>

                                </div>
                            </form>
                        </div><!--col-sm-6-->
                    </div><!--row-->
                </div>
            </div>

        </div>

    </div>
</div>

<!-- share product popup -->
<!-- share product popup -->


<!-- reminder popup -->
<!-- reminder popup -->
<div id="reminder_popup" class="modal fade reminder_popup" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Set Reminder</h4>
            </div>
            <div class="modal-body">
                <div class="form_div feedback">
                    <div class="row">
                        <div class="col-sm-12">
                            <form method="post">
                                <div class="form-group group">
                                    <textarea class="form-control"  ></textarea>
                                    <label >Message</label>
                                    <span class="bar"></span>
                                </div>
                                <span class="tag">Select Date & Time:</span>         
                                <div class="row form-group">
                                    <div class='col-xs-6'>
                                        <div class="form-group ">
                                            <div class='input-group date' id='datetimepicker1'>
                                                <input type='text' class="form-control" placeholder="Date & Time" />
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                                <span class="bar"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-6">
                                        <div class="form-group">
                                            <select>
                                                <option>daily</option>
                                                <option selected="selected">weekly</option>
                                                <option>monthly</option>
                                                <option>quarterly</option>
                                                <option>yearly</option>
                                            </select>
                                            <i class="fa fa-sort-desc" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class=" slider_cont text-center">
                                    <button type="submit" class="btn">save
                                    </button>
                                    <button type="submit" class="btn btn_black" data-dismiss="modal">cancel</button>
                                </div>
                            </form>
                        </div><!--col-sm-6-->
                    </div><!--row-->
                </div>
            </div>

        </div>

    </div>
</div>

<!-- reminder popup -->
<!-- reminder popup -->

<!-- more detail popup -->
<div id="moredetail" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>

            </div>
            <div class="modal-body">
                <div class="form_div feedback">
                    <div class="row">
                        <div class="col-sm-12">
                            <form method="post">
                                <div class="form-group group">
                                    <input type="text" placeholder="" class="form-control" id="user_priv" name="user_priv">
                                    <label >User Private</label>
                                    <span class="bar"></span>
                                </div>

                                <div class="form-group group">
                                    <input type="text" placeholder="" class="form-control" id="user_owner" name="user_owner">
                                    <label >User to Owner</label>
                                    <span class="bar"></span>
                                </div>
                                <div class="form-group group">
                                    <input type="text" placeholder="" class="form-control" id="owner_priv" name="owner_priv">
                                    <label >Owner Private</label>
                                    <span class="bar"></span>
                                </div>
                                <div class=" slider_cont text-center">
                                    <button type="submit" class="btn" name="contact_query">send<span></span>
                                    </button>
                                </div>
                            </form>
                        </div><!--col-sm-6-->
                    </div><!--row-->
                </div>
            </div>

        </div>

    </div>
</div>

<!-- more detail popup end -->
<?php get_footer(); ?>
<style>
i.mce-ico.mce-i-link {
        display: none !important;
    }
</style>
<script>
$(document).ready(function(){
   $('.btn_black').click(function(e){
    if (confirm('Are you sure')) { 
   // do things if OK
   }
   else {
    return false;
   }
 });
$('.not_plan_purchaged').click(function(e){
      $('.plan_error').html('Sorry! Please subscribe your plan to create and publish assert. below are the plans please have a look.');
      });
attachment_ids = [];
   $('#thumbnail-gallery .image').each(function () {
        var attachment_id = $(this).attr("data-attachment_id");
        attachment_ids.push(attachment_id);
    });
   $('#thumbnail-gallery #product_image_gallery').val(attachment_ids);
   var thumb_id = "<?php echo $thumb_id; ?>";
   $('#featured_image_id').val(thumb_id);
});

</script>
