<style>
  .postboxheight{
   height: auto;
 }
 .wp-admin #dashboard_right_now li{width: 100%;}
 .wp-admin #dashboard_right_now li a{float: right;width: 60px;}
 .tablewp{width:100%; vertical-align:top; border-spacing:0px;}
 .tablewp td{vertical-align:top;}
 .wphaedingfilter h4{display:inline-block;}
 .wphaedingfilter select{display:inline-block; margin-left:20px; margin-bottom:10px; display:inline-block;}
 .tablewp tr th{padding:5px 10px;font-size:16px;}
 .tablewp tr th:first-child{text-align:left;}
 .tablewp tr th:last-child{text-align:right;}
 .tablewp tr td:last-child{text-align:right;}
 .tablewp tr td:first-child{text-align:left;}
 .tablewp tr td{padding:8px 10px; font-size:14px;}
 .tablewp tr td span{display:block; padding:5px 0px;}
 .tablewp tr td table td{padding:15px; border-bottom:2px solid #000;}
 .tablewp tr td table tr:last-child td{border:none;}
 .tablewp tr td table{border-spacing:0px;}
 #postbox-container-1{width:100% !important;}
 .tablewp tr td.no-padding{padding:0px;}
 ul.tableul
 {
  width:100%;
  display:table;
}
ul.tableul li
{
  width:200px;
  display:table-cell;
}
ul.tableul li span {
  text-align: center;
  border: 1px solid #000000;
  height:40px;
  line-height:40px;
  display: block;
  color: #000;
  background: #fff;
}
ul.tableul2
{
  width:100%;
  display:table;
}
ul.tableul2 li
{
  display:table-row;
}
li.hidesecnd>span {
  color: #000;
  font-weight: 700;
}
.tb
{
  background:#fff;
}


ul.tableul.reporttable0
{
  margin-bottom:0px;
}
ul.tableul.reporttable1>li>span,ul.tableul.reporttable2>li>span {
  display: none;
}
ul.tableul.reporttable1,ul.tableul.reporttable2
{
  margin-top: 0px;
}

ul.tableul.reporttable1, ul.tableul.reporttable2 {
  margin-bottom: 0px;
  margin-top: 0px;
}

.table-bordered {
  border: 1px solid #ddd; 
}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th{    border: 1px solid #ddd;}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
  padding: 8px;
  line-height: 1.42857143;
  vertical-align: middle;
  border-style: solid;
  border-width: 0px 0px 1px 1px;
  border-color: #ddd;
  text-align: center;
}
.table>thead>tr>th:first-child, .table>tbody>tr:first-child td:first-child{
  border-left: 0;
}
.table>tbody>tr:last-child td, .table>tbody>tr:first-child td[rowspan]{border-bottom: 0}
</style>
<?php $obj = new UserReports();

?>
<div class="container" style="width:1350px; margin:auto;">
  <div id="dashboard-widgets-wrap">
    <div id="dashboard-widgets" class="metabox-holder">
     <h2>User asset-User Data Report</h2>
      <div class="tableSec">
       <table class="table table-bordered" width="100%" cellspacing="0" cellpadding="0">
         <thead>
           <tr>
             <th>Owner Name</th>
             <th>Owner Address</th>
             <th>Register date</th>
             <th>View</th>
             
           </tr>
         </thead>
         <tbody>
         <?php if(!empty($obj->invoice_report_user())){
            foreach($obj->invoice_report_user() as $userDetail){
             $asset_user = get_userdata($userDetail->ID);
             $address =  get_user_meta($userDetail->ID,'address',true);
             ?>
             <tr>
             <td><?php echo $asset_user->user_firstname; ?></td>
             <td><?php echo $address; ?></td>
             <td><?php echo $asset_user->user_registered; ?></td>
             <td><a href="<?php echo site_url(); ?>/wp-admin/edit.php?post_type=assets&page=report_asset&report_detail=report&userid=<?php echo $userDetail->ID; ?>">View report</a></td>
             </tr>
            <?php }
            } ?>

         </tbody>
       </table>
     </div>
   </div>
 </div>
</div>
