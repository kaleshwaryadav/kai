<script src="<?php echo get_template_directory_uri(); ?>/datatable/js/jquery-1.12.4.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/datatable//js/jquery.dataTables.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/datatable//js/dataTables.bootstrap4.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/datatable/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/datatable/css/dataTables.bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<h1>User Payment History</h1>
<table id="payment" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Sl No </th>
                <th>User Details</th>
                <th>Paypal Account Details</th>
                <th>Invoice ID</th>
                <th>Transaction ID</th>
                <th>Item Name</th>
                <th>Price</th>
                
                <th>Payment Status</th>
                <th>Payment On</th>                           
                
            </tr>
        </thead>
 
        <tbody>
        <?php global $wpdb;
         $table_name = $wpdb->prefix . "transaction_log";
         $result = $wpdb->get_results("SELECT * FROM $table_name ORDER BY ID DESC");
         //print_r($result);
         $j=1;
         if(!empty($result)){
            foreach($result as $item){
                $asset_user = get_userdata($item->payment_by_userid);
                $user_displayname = $asset_user->user_firstname;
                $user_email = $asset_user->user_email;
                
                if($item->payment_status==1){
                    $payment_status = "Complete";
                }else{
                    $payment_status = "Incomplete";
                }
                ?>
              <tr>
                <td><?php echo $j;  ?></td>
                
                 <td><?php echo $user_displayname."<br>".$user_email; ?></td>
                 <td><?php echo $item->payer_fullname."<br>".$item->payer_email."<br>".$item->payer_address."<br>"; ?>
                     <?php echo $item->payer_fullname;?>
                 </td>
                <td>#<?php echo  $item->invoice_id;?></td>
                <td><?php echo  $item->txn_id;?></td>
                <td><?php echo  $item->item_name;?></td>
                <td>$<?php echo  $item->payment_gross;  ?></td>               
                
                <td><?php echo $payment_status;  ?></td>

                <td><?php echo  $item->payment_date;  ?></td>
                
            </tr>

           <?php $j++; }
         }
         ?> 
      
        </tbody>
    </table>
<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button> -->
<div id="myModal" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span>

                </button>
                 <h4 class="modal-title">Message Form</h4>

            </div>
            <form id="myform" class="form-horizontal" role="form" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <div class="col-md-12">
                            <label class="control-label popup-label">To</label>
                            <input required type="text" class="form-control" name="email" value="deepak.singh@karmatech.in" readonly="">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <label class="control-label popup-label">Message</label>
                            <textarea class="form-control" name="message"></textarea>
                        </div>
                    </div>
                    <div id="error">
                        <div class="alert alert-danger"> <strong>Error!</strong> There Are Too Many Errors</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="submitForm">Submit</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="reset">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<div id="thanks"></div>
<script>
$(document).ready(function() {
    $('#payment').DataTable();
} );
</script>
