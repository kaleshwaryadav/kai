<?php

/* Google App Client Id */
define('CLIENT_ID', '62345540128-pf0k1h36ddmh6cr1v1l8g5k51q6u345r.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', '7CNgjLGoVI2djGEuaC2c1JU9');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/kaipro/assets/fashion-clothes-2');

?>
