<?php
/*
 * Template Name: Payment Success
 */
if($_POST){
global $current_user;
$username = $current_user->user_login;
$txn_id = $_POST['txn_id'];
$invoice_id = $_POST['item_number'];
$item_name = $_POST['item_name'];
$payer_email = $_POST['payer_email'];
$payer_fullname = $_POST['first_name']." ".$_POST['last_name'];
$payer_address = $_POST['address_name'].", ".$_POST['address_street'].", ".$_POST['address_city'].", ".$_POST['address_state'].", ".$_POST['address_country_code']."-".$_POST['address_zip'];
$payment_status = $_POST['payment_status'];
$payment_currency = $_POST['mc_currency'];
$payment_fee = $_POST['payment_fee'];
$payment_gross = $_POST['payment_gross'];
$payment_status = $_POST['payment_status'];
$payment_type = $_POST['payment_type'];
$payment_date = $_POST['payment_date'];
$business_id = $_POST['business'];
$payment_responce = print_r($_POST, true);
$user_id = get_current_user_id();
$reminder_status  = 1;
$isPaymentCompleted = false;
// $created_date = date('d-m-Y H:i:s');
$current_date = date('Y-m-d H:i:s');
global $wpdb;
$table_name = $wpdb->prefix . "transaction_log";

if($payment_status == "Completed") {
$table_name = $wpdb->prefix . "transaction_log";
$isPaymentCompleted = true;
$active = 1;
$payment_status = 1;
$sql = "SELECT * FROM $table_name where payment_by_userid='$user_id' and invoice_id='$invoice_id'";
$user_exits = $wpdb->get_row($sql);
if($user_exits->payment_by_userid==$user_id){
$updateSql = "UPDATE " . $table_name ." SET item_name = '$item_name', payment_status = '$payment_status', payment_amount = '$payment_gross', payer_email='$payer_email', payment_gross = '$payment_gross' , payment_status = '$payment_status', payment_date = '$payment_date', updated_date = '$current_date', reminder_status = '1', payment_responce = '$payment_responce' WHERE payment_by_userid = '$user_id' and invoice_id='$invoice_id'";
$result = $wpdb->query($updateSql);
if($result){
$table_name_update = $wpdb->prefix . "montly_payment_report";  
$updateSql = "UPDATE " . $table_name_update ." SET Payment_Status = '1', Updated_DateTime = NOW() WHERE UserID = '$user_id' and ID='$invoice_id'";
$update_res = $wpdb->query($updateSql);
if($update_res){ $responce = "1"; }
}
}
else {
$insertSQL = "INSERT INTO " . $table_name . " SET txn_id = '$txn_id', invoice_id = '$invoice_id', item_name = '$item_name', payment_amount = '$payment_gross', payer_email='$payer_email', payer_fullname='$payer_fullname', payer_address='$payer_address', currency='$payment_currency', payment_fee ='$payment_fee', payment_gross ='$payment_gross', payment_status='$payment_status', payment_type='$payment_type', payment_date='$payment_date', business='$business_id', payment_responce = '$payment_responce', payment_by_userid = '$user_id', reminder_status='1', created_date = NOW()";
$results = $wpdb->query($insertSQL);
if($results){
$table_name_update = $wpdb->prefix . "montly_payment_report";  
$updateSql = "UPDATE " . $table_name_update ." SET Payment_Status = '1', Updated_DateTime = NOW() WHERE UserID = '$user_id' and ID='$invoice_id'";
$update_res = $wpdb->query($updateSql);
if($update_res){ $responce = "2"; }
}
else {
$responce = "0";
}
}
}
get_header();
$sql = "SELECT * FROM $table_name where txn_id='$txn_id'";
$transaction = $wpdb->get_row($sql);
$owner_id = $transaction->payment_by_userid;
$asset_user = get_userdata($owner_id);
$user_displayname = $asset_user->user_firstname;
$address =  get_user_meta($owner_id,'address',true);
?>
<div class="template-wrapper">
  <section>
          <div class="container">
              <div class="breadcrumb">
                <?php //echo "responce~~~~~".$responce; ?>
                <h1>Payment Confirmation</h1>
                <h4>Your payment has been successfully processed. Thank you.</h4>
                <br/>
                <section>
                  <h4 class="payment_success_section">Payment Information</h4>
                  <table style="width:50% !important">
                    <tr>
                      <td width="50%">Transaction #</td>
                      <td width="50%"><b><?php echo $transaction->txn_id ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Transaction Date Time </td>
                      <td width="50%"><b><?php echo $transaction->payment_date ?></b></td>
                    </tr>                    
                    <tr>
                      <td width="50%">Transaction Amount</td>
                      <td width="50%"><b><?php echo $transaction->payment_amount ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Currency</td>
                      <td width="50%"><b><?php echo $transaction->currency ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Transaction Status</td>
                      <td width="50%"><b>Complete</b></td>
                    </tr>
                  </table>
                </section>
                 <section>
                  <h4 class="payment_success_section">Invoice Information</h4>
                  <table style="width:50% !important">
                    <tr>
                      <td width="50%">Invoice ID #</td>
                      <td width="50%"><b><?php echo $transaction->invoice_id ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Invoice Title </td>
                      <td width="50%"><b><?php echo $transaction->item_name ?></b></td>
                    </tr> 
                    <tr>
                      <td width="50%">Invoice Amount </td>
                      <td width="50%"><b><?php echo $transaction->payment_amount ?></b></td>
                    </tr>
                  </table>
                </section>
                <section>
                  <h4 class="payment_success_section">Payer Information</h4>
                  <table style="width:50% !important">
                    <tr>
                      <td width="50%">Name </td>
                      <td width="50%"><b><?php echo $transaction->payer_fullname ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Email Address #</td>
                      <td width="50%"><b><?php echo $transaction->payer_email ?></b></td>
                    </tr> 
                    <tr>
                      <td width="50%">Address</td>
                      <td width="50%"><b><?php echo $transaction->payer_address ?></b></td>
                    </tr>
                  </table>
                </section>
                <section>
                  <h4 class="payment_success_section">Asset Owner More Information</h4>
                  <table style="width:50% !important">
                    <tr>
                      <td width="50%">Name </td>
                      <td width="50%"><b><?php echo $user_displayname ?></b></td>
                    </tr>
                    <tr>
                      <td width="50%">Address </td>
                      <td width="50%"><b><?php echo $address ?></b></td>
                    </tr>                      
                  </table>
                </section>
              </div>
           </div>
  </section>
</div>
<?php get_footer();
}
else{
  echo "Sorry you are not authorized to view this page.";
}
?>