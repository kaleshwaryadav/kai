<?php
/*
 * Template Name: Payment Cancel
 */

get_header();
?>
<div class="template-wrapper">
<section>
        <div class="container">
            <div class="breadcrumb">
              
            </div>
        <div style='text-align:center; color:red;'>Sorry ! Transaction failed , try once again </div>
 </div>
 </section>
</div>
 <?php get_footer();?>



