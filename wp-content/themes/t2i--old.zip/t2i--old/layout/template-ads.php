<?php 
$terms = get_the_terms( $post->ID, 'asset-detail');
if(!empty($terms))
foreach ( $terms as $term ) {
    $termID[] = $term->term_id;
}
$temlate_id = $termID[0];
$ads = array('post_type' => 'adds',
                   'post_status' => 'publish',
                   'posts_per_page'=>4, 
                   'order' => 'DESC',
                   'tax_query' => array(
                        array(
                            'taxonomy' => 'asset-detail',
                            'field' => 'term_id',
                            'terms' => $temlate_id,
                        )
                 )
               ); 
                $ads_list =  get_posts($ads);
                ?>
                <?php if($ads_list){
                foreach($ads_list as $item){
                $adslink = get_field('ads_link',$item->ID);
                $ImageUrl = wp_get_attachment_image_src( get_post_thumbnail_id($item->ID ), 'full');
                if(!empty($adslink)){
                    $links = $adslink;
                }
                else {
                    $links = '#'; 
                }
                $categoriy_id = wp_get_post_categories($post->ID);
                ?>
            
                <div class="col-sm-3 col-xs-6 text-center">
                 <a href="<?php echo $adslink; ?>" onclick="add_click('<?php echo $item->ID; ?>','<?php echo $temlate_id; ?>','<?php echo $categoriy_id[0]; ?>');"  >
                 <img class="img-responsive" src="<?php echo $ImageUrl[0]; ?>" alt="">
                </a>
                </div>
   <?php } } ?>
    

