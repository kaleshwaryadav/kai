<?php
class student{

    function __construct() {
    }

    public function student_class(){
       echo  $text = "Hi, Kaleshwar yadav";
       
    }
}
new student();








 ?>