<?php
session_start();
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage T2i
 * @since 1.0
 * @version 1.0
 */

get_header();?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php 
$userID = get_current_user_id();

global $current_user;
$current_user->user_email;
$ImageUrl = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full');
$terms = get_the_terms( $post->ID, 'asset-detail');
if(!empty($terms))
foreach ( $terms as $term ) {
    $termID[] = $term->term_id;
}
$temlate_id = $termID[0];
$asset_categoriy_id = wp_get_post_categories($post->ID);
function wp_asset_set_post_views($temlate_id, $asset_categoriy_id){
  $post_id = get_the_ID();
  $ip_address = get_client_ip();
  $obj= new UserReports();
  $browser = $_SERVER['HTTP_USER_AGENT'];
  global  $current_user, $wpdb;
  $table_name = $wpdb->prefix . "asset_views";
  $user_id = 1;
  $currentdate = date('Y-m-d');
  $plan_id = CheckPlanAssetsViewPost($temlate_id);
  $open_asset_cost = $obj->get_current_subscription_data($plan_id, 'open_asset');
  $insertLogSQL = "INSERT INTO " . $table_name . " 
        SET       
        user_id = '$user_id',
        post_id = '$post_id',
        template_id = '$temlate_id',
        category_id = '$asset_categoriy_id[0]',
        user_ip = '$ip_address',
        user_agent = '$browser',
        per_cost = '$open_asset_cost',        
        date = '$currentdate'";
  $results1 = $wpdb->query($insertLogSQL);
}
?>

<div class="template-wrapper extended">
    <div>
        <div class="container">
            <div class="breadcrumb">
                <?php if(function_exists('bcn_display'))
                {
                    bcn_display();
                }
                echo wp_asset_set_post_views($temlate_id, $asset_categoriy_id);                
                // wpb_set_post_views(get_the_ID());                
                ?>
            </div>
            <div class="head_ttl">
                <h2><?php the_title(); ?></h2>
                <a href="#target" class="print"></a>
            </div>
            
            <div class="product_details ">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="demo">
                            <div class="item">            
                                <div class="clearfix" >
                                    <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                                        <?php $galleryImage = get_field('select_image',get_the_ID()); 

                                          if(!empty($galleryImage)){
                                          foreach($galleryImage as $items){?>
                                           <li data-thumb="<?php echo $items['url']; ?>"> 
                                            <img src="<?php echo $items['url']; ?>"  alt="slider_img" />
                                           </li>
                                         <?php } }
                                        else { echo "Its no use";?>
                                            <li data-thumb="<?php echo $ImageUrl[0]; ?>"> 
                                            <img src="<?php echo $ImageUrl[0]; ?>"  alt="slider_img" />
                                           </li>
                                          
                                       <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>  
                    </div>
                    <div class="col-sm-6">
                         <div class="product_dtl">
                           <?php echo the_field('short_description',get_the_ID()); ?>
                            <div class="features">
                            <?php  $asset_link = get_field('asset_link', get_the_ID(),true);
                            //echo $asset_link;
                             if(!empty($asset_link)){?>
                             <span><a class="track_link" data-userid="<?php echo $userID; ?>" data-postid="<?php echo get_the_ID(); ?>" data-tempid="<?php echo $temlate_id;  ?>" data-catid="<?php echo $asset_categoriy_id[0];  ?>" href="<?php echo $asset_link; ?>" target="_blank"><?php echo $asset_link; ?></a></span>
                            <?php } ?>

                            <?php $price =  get_field('price', get_the_ID());
                              if(!empty($price)){?>
                                <span class="aset_price">Asset Price : <span class="">$<?php echo $price; ?></span></span>
                                <?php } ?> 
                                <span style="float:left;">
                                <?php $downloadUrl = get_field('download_file', get_the_ID()); 
                                if(!empty($downloadUrl)){?>
                                <a class="download_asset btn" data-userid="<?php echo $userID; ?>" data-postid="<?php echo get_the_ID(); ?>" data-tempid="<?php echo $temlate_id;  ?>" data-catid="<?php echo $asset_categoriy_id[0];  ?>" href="<?php echo $downloadUrl; ?>" download>download pdf</a>
                                <?php } ?>
                                <?php  $link =  get_field('link', get_the_ID());
                                if(!empty($link)){?>
                                <a href="<?php echo $link; ?>" target="_blank" class="btn btn_bdr ">Order</a>
                                <?php } ?>
                                </span>
                            </div>

                        </div>
                    </div>
                </div>
                <?php
                $desc_second = get_field('description_business',get_the_ID());
               if(!empty($desc_second)){
                wp_editor(  $desc_second, 'second_description', array( 'theme_advanced_buttons1' => 'bold, italic, ul, pH, pH_min', "media_buttons" => false, "textarea_rows" => 8, "tabindex" => 4 ) );
               }
               ?>
              </div>

             <?php 
             $owneruser  =  get_post($post->ID);
             $user_roles = $current_user->roles;
             $first_name =  get_user_meta($owneruser->post_author,'first_name',true);
             $location   = get_user_meta($owneruser->post_author,'location',true);
             $UserPic    = get_user_meta($owneruser->post_author,'user_picImage',true); 
             ?>
            
              <div class="row no-margin">
                <h3>Detail</h3>
                <div class="col-md-5 col-sm-5 col-xs-12 no-padding">
                    <div class="uploader-user">
                    <?php if(!empty($UserPic)){?>  
                         <img class="img-responsive center-block" src="<?php bloginfo('template_url') ?>/assets/images/user-icon.png" alt="" width="94" height="95">
                        <?php } else { ?>
                        <img class="img-responsive center-block" src="<?php bloginfo('template_url') ?>/assets/images/user-icon.png" alt="">
                        <?php } ?>
                        <div class="details_owner ">
    
                             <div class="media-body">

                                <ul class="first_not">
                                    <li>
                                        <ul>
                                            <li> Contact Name :</li>
                                            <li> <?php echo $first_name; ?> </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <ul>
                                            <li> Location : </li>
                                            <li><?php echo $location; ?></li>
                                        </ul>
                                    </li>
                                </ul>
                                <a href="#" class="btn" data-toggle="modal" data-target="#moredetail" >more detail</a>
           
                            </div>
                            
                        </div>
                           
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-12 no-padding">
                     <div class="msg_status" style="position: relative; top: -10px;"></div>
                    <?php $assetInfo = get_post($post->ID);
                          $userInfo = get_user_by( 'id', $assetInfo->post_author);
                          $new_user = get_userdata($assetInfo->post_author);
                          //$new_user = get_userdata($assetInfo->post_author);
                          //print_r($new_user);                         

                        if($assetInfo->post_author!=$userID){?>
                        <div class="message-form-owner fullwidth">
                          <form id="message-form" role="form">

                    <div class="messages"></div>

                    <div class="controls">
                        
                            
                                   <input type="hidden" name="sender" value="<?php echo $new_user->user_email; ?>">
                                     <input type="hidden" name="asset_ownername" value="<?php echo $new_user->user_firstname; ?>">                                      
                                      <input type="hidden" name="action" value="send_msg_to_owner">
                                      <input type="hidden" name="category_id" value="<?php echo $asset_categoriy_id[0]; ?>">
                                      <input type="hidden" name="template_id" value="<?php echo $temlate_id; ?>">
                                      <input type="hidden" name="postid" value="<?php echo get_the_ID(); ?>">
                                      <input type="hidden" name="usertoowner" id="usertoowner" value="<?php echo $new_user->ID ?>">    
                                  
                               
                                      <div class="row">
                             <div class="col-lg-6">
                                <div class="form-group">                                    
                                    <input id="form_name" type="text" name="u_name" class="form-control w-100" placeholder="Name *" required="required"
                                        data-error="Enter Name.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">                                    
                                    <input id="form_phone" type="number" name="m_number" class="form-control w-100" placeholder="Mobile Number" required="required">
                                        <input type="hidden" name="post_title" value="<?php echo $assetInfo->post_title; ?>">     
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">                                    
                                    <input id="form_email" type="email" name="email" class="form-control w-100" placeholder="E-mail id *" required="required"
                                        data-error="Valid email is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                   
                                     <textarea id="form_message" name="address" class="form-control" placeholder="address *" rows="4" required="required"
                                data-error="Please, enter address."></textarea>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                              <div class="form-group">
                              <textarea id="form_address" name="message" class="form-control" placeholder="Message *" rows="4" required="required"
                                data-error="Please, leave us a message."></textarea>
                            <div class="help-block with-errors"></div>
                            </div>
                        </div>                        

                        <div class="col-lg-12">
                        <div class="form-group ">

                            <div class="g-recaptcha" data-sitekey="6LfjWXsUAAAAAOfxSwvmwbqa7fkMwMqG-OurXKUd" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors captcha_error"></div>
                        </div>
                      </div>

                        <div class="col-lg-12 captcatdiv">
                        <div class="form-group btn-submitmessage ">
                          <input type="submit" class="btn profile-update-button" value="Send message">
                        </div>
                      </div>
                        

                    </div>

                </form>
                         
                            <!-- <form id="sendMSG" method="post">
                                <div>
                                    <div class="col-md-6 col-xs-12">
                                     <input type="hidden" name="sender" value="<?php echo $current_user->user_email; ?>">
                                     <input type="hidden" name="asset_ownername" value="<?php echo $new_user->user_firstname; ?>">
                                      <input type="text" class="form-control w-100" name="u_name" placeholder="Name" required="">
                                      <input type="hidden" name="action" value="send_msg_to_owner">
                                      <input type="hidden" name="category_id" value="<?php echo $asset_categoriy_id[0]; ?>">
                                      <input type="hidden" name="template_id" value="<?php echo $temlate_id; ?>">
                                      <input type="hidden" name="postid" value="<?php echo get_the_ID(); ?>">
                                      <input type="hidden" name="usertoowner" id="usertoowner" value="<?php echo $new_user->ID ?>">
                                    </div>
                                     <div class="col-md-6 col-xs-12">
                                        <input class="form-control w-100" type="number" name="m_number" placeholder="Mobile Number" required="" >
                                        <input type="hidden" name="post_title" value="<?php echo $assetInfo->post_title; ?>">
                                        <input type ="hidden" name="email" value="<?php echo $userInfo->user_email; ?>">
                                     </div>
                                    <div class="col-xs-12">
                                     <input class="form-control w-100" type="email" name="user_emailid" placeholder="E-mail id" required="">
                                    </div>
                                    <div class="col-xs-12">
                                        <input class="form-control w-100" type="text" name="address" placeholder="Address" required="">
                                    </div>
                                    <div class="col-xs-12">
                                        <input class="form-control w-100" type="text" name="message" placeholder="Message" required="">
                                    </div>

                                    <div class="col-xs-12">
                                    <div class="g-recaptcha" data-sitekey="6LfjWXsUAAAAAOfxSwvmwbqa7fkMwMqG-OurXKUd"></div>
                                    </div>
                                    <div class="col-xs-12 fullwidth mt-20">
                                        <button class="btn msgassert">SEND</button>
                                    </div>
                            </form> -->
                        </div>
                        <?php } else {?>
                    <div class="contact-form fullwidth">
                       <h4><strong> Person to owner Notes:</strong></h4>
                        <div class="col-xs-12 usernotes">
                        <?php $UserToOwnerData = GetUserNotes($post->ID);
                        if(!empty($UserToOwnerData)) { 
                          foreach($UserToOwnerData as $notes){ $user = get_user_by('id', $notes['user_id']); ?>
                          <div class="customLabel">
                          </div>
                          <div class="chat_inline">
                          <div class="user_dtls">
                            <div class="media">
                                <div class="media-left media-middle">
                                    <img class="media-object" width="55" src="<?php bloginfo('template_url') ?>/assets/images/user-icon.png" alt="Media Object">
                                </div>
                                <div class="media-body media-middle">
                                    <span class="mem_name"><?php echo $user->data->user_login; ?></span>
                                    <span class="chat_time"><?php echo date('d-m-Y', strtotime($notes['date'])); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="user_text">
                            <div class="text_fld">
                                <p><?php echo $notes['user_to_owner_note']; ?></p>
                            </div>
                        </div>
                    </div>


                    <?php } } else  echo'<div style="color:red;">There are no Notes available currently </div>'; } ?>
                    </div>
                    </div>      
                </div>
          
                
            </div> 
       
 
             
        </div>

        <div class="partner-list">
            <div class="container">

                <div class="row">
                   <?php get_template_part( 'layout/template', 'ads');?>
               </div>
            </div>  
        </div>

        <div>
        <?php get_template_part( 'layout/template', 'share');?>
        </div>
    </div>  <!-- template wrapper ends here -->

    <!-- share product popup -->
    <!-- share product popup -->
    <div id="share_product" class="modal fade reminder_popup" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Share this assest via</h4>
                </div>
                <div class="modal-body">
                    <div class="form_div feedback">
                    <div class="status" style="text-align:center;"></div>
                        <div class="row">
                            <div class="col-sm-12">
                              <?php ?>
                                <form method="post" action="#" id="shareemail">
                                    <input type="hidden" name="assert_url" value="<?php echo get_permalink(get_the_ID()); ?>">
                                    <input type="hidden" name="action" value="share_assert_byemail">
                                    <input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
                                    <input type="hidden" name="template_id" value="<?php echo $temlate_id; ?>">
                                    <input type="hidden" name="category_id" value="<?php echo $asset_categoriy_id[0]; ?>">
                                   
                                    <div class="form-group group">
                                        <input type="email" name="email_assert" class="form-control" required="">
                                        <label>Email Address</label>
                                        <span class="bar"></span>
                                    </div>
                                    <div class="form-group group">
                                        <textarea class="form-control" name="msg_assert" id="msg_assert"  required=""></textarea>
                                        <label>Message</label>
                                        <span class="bar"></span>
                                    
                                    </div>
                                    <div class=" slider_cont text-center">
                                        <button type="submit" class="btn shareassert">submit
                                        </button>

                                    </div>

                                    <div class="form-group">
                                    <?php 

                                          $assert_desc = get_post(get_the_ID());
                                          $title   = urlencode(get_the_title());
                                          $url     = urlencode(get_the_permalink(get_the_ID()));
                                          $summary = urlencode($assert_desc->post_content);
                                          $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full');
                                          ?>
                                        
                                        <ul class="social_list">
                                            <li class="fb">
                                            <a onClick="window.open('http://www.facebook.com/sharer.php?s=100p[title]=<?php echo $title;?>p[summary]=<?php echo $summary;?>p[url]=<?php echo $url; ?>&p[images][0]=<?php echo $image[0];?>', 'sharer', 'toolbar=0,status=0,width=548,height=325');" target="_blank"><span><i class="fa fa-facebook" aria-hidden="true"></i></span>Facebook</a></li>
                                            <li class="twt"><a href="https://www.twitter.com/share?url=<?php echo urlencode(get_the_permalink(get_the_ID())); ?>" target="_blank" data-toggle="tooltip" ><span><i class="fa fa-twitter" aria-hidden="true"></i></span>twitter</a></li>
                                            <li class="gp"><a href="https://plus.google.com/share?url=<?php echo urlencode(get_the_permalink(get_the_ID())); ?>"  target="_blank"><span><i class="fa fa-google-plus" aria-hidden="true"></i></span>google +</a></li>
                                        </ul>
                                    </div>

                                    
                                </form>
                            </div><!--col-sm-6-->
                        </div><!--row-->
                    </div>
                </div>

            </div>

        </div>
    </div>

    <!-- share product popup -->
    <!-- share product popup -->


    <!-- reminder popup -->
    <!-- reminder popup -->
    <div id="reminder_popup" class="modal fade reminder_popup" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Set Reminder</h4>
                    <div class="reminderMsg" style="text-align:center;"></div>
                </div>
                <div class="modal-body">
                    <div class="form_div feedback">
                        <div class="row">
                            <div class="col-sm-12">
                                <form method="post" id="set_remainder" >
                                 <input type="hidden" id="event-title" value="<?php echo get_the_title(get_the_ID()); ?>" autocomplete="off" />
                                  <input type="hidden" name="action" value="assert_remainder">
                                  <input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
                                  <input type="hidden" name="template_id" value="<?php echo $temlate_id; ?>
                                  ">
                                  <input type="hidden" name="category_id" value="<?php echo $asset_categoriy_id[0]; ?>
                                  ">
                                    <div class="form-group group">
                                        <textarea class="form-control" name="message"></textarea>
                                        <label >Message</label>
                                        <span class="bar"></span>
                                    </div>
                                    <span class="tag">Select Date & Time:</span>         
                                    <div class="row form-group">
                                        <div class='col-xs-6'>
                                            <div class="form-group ">
                                                <div class='input-group date'>
                                                    <input type="text" name="remainder_date" id="event-date" placeholder="Date & Time" lass="form-control" autocomplete="off" /> 
                                                    <input type="hidden" id="event-start-time" placeholder="Event Start Time" autocomplete="off" />
                                                    <input type="hidden" id="event-end-time" placeholder="Event End Time" autocomplete="off" />
                                                    <span class="input-group-addon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                    <span class="bar"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xs-6">
                                            <div class="form-group">
                                                <select name="event-type" id="event-type">
                                                    <option value="">Please select an option</option>
                                                    <option value="daily">Daily</option>
                                                    <option value="weekly">Weekly</option>
                                                    <option value="monthly">Monthly</option>
                                                    <option value="quarterly">Quarterly</option>
                                                    <option value="yearly">Yearly</option>
                                                </select>
                                                <i class="fa fa-sort-desc" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class=" slider_cont text-center">
                                        <button type="submit" class="btn reminder">save</button>
                                        <button type="submit" class="btn btn_black" data-dismiss="modal">cancel</button>
                                    </div>
                                </form>
                            </div><!--col-sm-6-->
                           
                        </div><!--row-->
                    </div>
                </div>

            </div>

        </div>
    </div>

    <!-- reminder popup -->
    <!-- reminder popup -->

    <!-- more detail popup -->

            
    <div id="moredetail" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <?php
              global  $current_user, $wpdb;
              $table_name = $wpdb->prefix . "user_asset_accesslevel";
              $user_id = get_current_user_id();
              $post_id = get_the_ID();
              $owneruser =  get_post($post->ID);
              $user_roles = $current_user->roles;
              if ($user_roles[0]=='administrator') {
              $visible = "administrator";
              }
              else if($owneruser->post_author==$userID){
              $visible ="owner";
              }
              else if($owneruser->post_author!=$userID){
              $visible ="notowner";
              }
              $UserAccess = $wpdb->get_row("SELECT * FROM $table_name where user_id='$user_id' and post_id = '$post_id' ORDER BY id DESC");
              $user_p    =  $UserAccess->user_private_note;
              $u_owner   =  $UserAccess->user_to_owner_note; 
              $o_private =  $UserAccess->owner_private_note; 
              ?>
                <div class="modal-body">
                    <div class="form_div feedback">
                        <div class="row">
                            <div class="col-sm-12">
                            <div class="status" style="text-align:center;"></div>
                             <?php if(is_user_logged_in()){ ?>
                             <form method="post" id="UserAccessLevel">
                             <input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
                             <input type="hidden" name="action" value="accessLevel">
                            <?php  switch($visible): 
                                    case 'administrator': ?>
                                    <div class="form-group group">
                                    <textarea placeholder="Type here" class="form-control" rows="2" name="user_priv" id="user_priv"><?php if(!empty($user_p)){ echo $user_p; } ?></textarea>
                                    <label >User Private</label>
                                        <span class="bar"></span>
                                    </div>

                                    <div class="form-group group">
                                    <textarea placeholder="This message will be seen to asset owner" class="form-control" rows="2" name="user_owner" id="user_owner"><?php if(!empty($u_owner)){ echo $u_owner; } ?></textarea>
                                    <label >User to Owner</label>
                                    <span class="bar"></span>
                                    </div>
                                    <div class="form-group group">
                                     <textarea placeholder="Type here" class="form-control" rows="2" name="owner_priv" id="owner_priv"><?php if(!empty($o_private)){ echo $o_private; } ?></textarea>
                                     <label >Owner Private</label>
                                     <span class="bar"></span>
                                    </div>
                                    <?php break;?>
                                    <?php case 'owner': ?>
                                    <div class="form-group group">
                                    <textarea placeholder="This message will be seen to asset owner" class="form-control" rows="2" name="user_owner" id="user_owner" readonly="true"><?php if(!empty($u_owner)){ echo $u_owner; } ?> </textarea>
                                    <label >User to Owner</label>
                                    <span class="bar"></span>
                                    </div>
                                    <div class="form-group group">
                                     <textarea placeholder="Type here" class="form-control" rows="2" name="owner_priv" id="owner_priv"><?php if(!empty($o_private)){ echo $o_private; } ?></textarea>
                                     <label >Owner Private</label>
                                     <span class="bar"></span>
                                    </div>
                                    <?php break;?>
                                    <?php case 'notowner': ?>
                                   <div class="form-group group">
                                    <textarea placeholder="Type here" class="form-control" rows="2" name="user_priv" id="user_priv" ><?php if(!empty($user_p)){ echo $user_p; } ?></textarea>
                                    <label >User Private</label>
                                        <span class="bar"></span>
                                    </div>

                                    <div class="form-group group">
                                    <textarea placeholder="This message will be seen to asset owner" class="form-control" rows="2" name="user_owner" id="user_owner"><?php if(!empty($u_owner)){ echo $u_owner; } ?></textarea>
                                    <label >User to Owner</label>
                                    <span class="bar"></span>
                                    </div>
                                    <?php break;?>
                                    <?php endswitch;?>
                                    
                                    <div class=" slider_cont text-center">
                                    <button class="private_acesslevel" type="submit" class="btn" name="contact_query">Save<span></span>
                                    </button>

                                    </div>
                                </form>
                                <?php } else {
                                   echo"Only for registered users";
                                } ?>
                            </div><!--col-sm-6-->

                        </div><!--row-->
                    </div>
                </div>

            </div>

        </div>
    </div>
<!-- more detail popup end -->

    <style>
    .status {
        color: green;
    }
    .error {
        color:red;
    }
    .template-wrapper {
    background-color: #f6f6f6;
    padding-bottom: 0px !important; 
    }
    input[type="text"] {
    border: 1px solid rgba(0, 0, 0, 0.15);
    font-family: inherit;
    font-size: inherit;
    padding: 8px;
    border-radius: 0px;
    outline: none;
    display: block;
    margin: 0 0 20px 0;
    width: 100%;
    box-sizing: border-box;
   }

    i.mce-ico.mce-i-link {
        display: none !important;
    }

   </style>
    <!-- more detail popup end -->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.css" />
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.1.9/jquery.datetimepicker.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_url') ?>/assets/js/lightslider.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image-gallery').lightSlider({
                gallery:true,
                item:1,
                thumbItem:4,
                slideMargin: 0,
                speed:500,
                auto:false,
                loop:true,
                onSliderLoad: function() {
                    $('#image-gallery').removeClass('cS-hidden');
                }  
            });
        });
    </script>
    <script type="text/javascript">
        bkLib.onDomLoaded(function() {
            new nicEditor({iconsPath : 'js/nicEditorIcons.gif'}).panelInstance('area3');
        });
    </script>
    <script type="text/javascript">
    // jQuery(function () {
    //  jQuery('#datetimepicker1').datetimepicker();

    // });
</script>
<script type="text/javascript">

    $('.head_ttl .print').on('click', function(e) {
        e.preventDefault();
        $link = $(this).attr('href');

        $('html, body').animate({
            scrollTop: $($link).offset().top - 10
        }, 800 );
    });

function AdjustMinTime(ct) {
    var dtob = new Date(),
        current_date = dtob.getDate(),
        current_month = dtob.getMonth() + 1,
        current_year = dtob.getFullYear();
            
    var full_date = current_year + '-' +
                    ( current_month < 10 ? '0' + current_month : current_month ) + '-' + 
                    ( current_date < 10 ? '0' + current_date : current_date );

    if(ct.dateFormat('Y-m-d') == full_date)
        this.setOptions({ minTime: 0 });
    else 
        this.setOptions({ minTime: false });
}

$("#event-start-time, #event-end-time,#event-date").datetimepicker({ format: 'Y-m-d H:i', minDate: 0, minTime: 0, step: 5, onShow: AdjustMinTime, onSelectDate: AdjustMinTime });

$('#UserAccessLevel').submit(function(event){
$('.private_acesslevel').text('Processing..');
$.ajax({          
        type: 'POST',
        dataType: 'json',
        url: theme_ajax.url,
        data: $(this).serialize(),
        success: function (response) {
        $('.private_acesslevel').text('Save');
        if (response.status == "Success"){
        $('.status').html(response.message);
        setTimeout(function(){// wait for 5 secs(2)
        $('.status').hide();
        }, 2000);
        }
        }
    });
return false;
});

</script>
<script type="text/javascript">
$(document).ready(function(){
 tinyMCE.init({
    setup: function(ed) {
        if ($('#second_description').prop('readonly')) {
            ed.settings.readonly = true;
        }
    }
});   
$('#second_description').attr("readonly","readonly");
$('#usertoowner').val($('#user_owner').val());


});
</script>
<?php get_footer();
