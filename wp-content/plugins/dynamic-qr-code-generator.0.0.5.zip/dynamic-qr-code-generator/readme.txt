=== Dynamic QR Code Generator===
Contributors: r4kib.hbo
Donate link: http://www.rakibh.com/
Tags: QR code, 2D code, QR
Requires at least: 3.0.1
Tested up to: 4.8.1
Stable tag: 0.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Generate QR code for every page, post or whole Wordpress site. Share Smartly.

== Description ==

(Quick Response code) A two-dimensional bar code that is widely used to cause a Web page to download into the user's smartphone when scanned with a mobile tagging app. 'Dyanomic QR Code Generator' plugin generate qr code for each and every page, post and site url . Its easy to use from your sidebars. No setting up needed just plug and play.

= Shortcode =
* [dqr_code] - shows QR code for permalink of current post, page or custom post type.
* [dqr_code url="http://example.com"] - shows QR code for "http://example.com".
* [dqr_code post_id="99"] - shows QR code for permalink of post ID "99". (supports post,page or custom post type).
* [dqr_code url="http://example.com"] - shows QR code for "http://example.com" and the 'post_id' parameter will be denied.
* [dqr_code url="http://example.com" size="300" color="#000000" bgcolor="#ffffff"] - shows QR code for "http://example.com". Where the QR code will be 300px X300px size and will have "#000000" as color and "#ffffff" as background color. Defaults: Size= 200, Color="#000000", Background Color="#ffffff"; 

= Key Feratures: =

* Easy install
* Very easy to configure.
* Easy to use shortcode.

= Rate us/ Feedback: =

Please take the time to let us and others know about your experiences by leaving a review, so that we can improve the plugin for you and other users.

= Need More? =
Please contact us if you need custom features or any other things.

== Installation ==

1.Download the Plugin.
1.Unzip the pluginusing 7Zip or Winzip.
1. Upload `dynamic_qr_code_generator` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Enjoy the power of QR codes.

== Frequently Asked Questions ==

= Is this plugin 100% free? =
Yes! and always will be.

=Is this Ad-free?=
Yes. 100% Ad-free.

= Can I use it commercialy? =
Yes! You are always free to use coomercially.



== Screenshots ==

1. QR code for Site URL
2. QR code on Sidebar of Page Editor
3. QR code on Sidebar of Post Editor

== Changelog ==

=0.0.5=
Move to JS for being future proof.
Added shortcode [dqr_code]

= 0.0.1 =
Minor fixes in functionality