<?php
if (! class_exists ( 'PostmanStateIdMissingException' )) {
	class PostmanStateIdMissingException extends Exception {
	}
}