<?php

class Postman_Mandrill_Internal {
    public function __construct(Postman_Mandrill $master) {
        $this->master = $master;
    }

}


